getProbsDR <-
function(m, group=1, newdata, timepoints=NULL, start=0) {
    if (is.null(timepoints)) {
        stop("timepoints required")
    } else {
        timepoints <- as.double(timepoints)
    }
    tra <- attr(newdata, "trans")
    probs <- list()
    StartHaz <- mstate::msfit(m, newdata=newdata, trans=tra)
    StartHaz <- StartHaz$Haz
    tmp <- split(StartHaz, StartHaz$trans)
    Times <- tmp[[1]]$time
    StartHaz <- do.call("cbind", lapply(tmp, function(x) x$Haz))
    group <- (group-1)*9 + 1
    StartHaz <- StartHaz[,group:(group+8)]
    StartdHaz <- apply(rbind(0, StartHaz), 2, diff)
    p.d.c <- .Call("VectorPDC",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                   timepoints=timepoints, PACKAGE="brcarepred")
    p.d.o <- .Call("VectorPDO",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                timepoints=timepoints, PACKAGE="brcarepred")
    p.d <- 1 - (p.d.c + p.d.o)
    probs <- list(timepoints, p.d, p.d.c, p.d.o)
    names(probs) <- c("Times", "p.d", "p.d.c", "p.d.o")
    probs
}
