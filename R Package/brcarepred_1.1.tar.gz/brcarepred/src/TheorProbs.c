#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <R.h>
#include <Rmath.h>
#include <R_ext/Utils.h>
#include <Rinternals.h>

double S2(int u, int t, int k, const double *Haz) {
  double res; res=0;
  res = exp(-((Haz[7* k+ u-1] + Haz[8* k+ u-1]) - (Haz[7* k+ t-1] +
						       Haz[8* k+ t-1])));
  return(res);
}

int FirstNonNeg(const double *x, const int n) {
  int i;
  for (i=0; i<n; i++) {
    if (x[i]>=0) {
      return(i+1);
    }
  }
  return(i+1);
}

double PDC(double u, double t,  int k,  int n,
	 double *Haz,
	 double *dHaz, double *Times) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double res; res=0;
  int i,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  for (i= t2-1; i< u2; i++) {
    res = res + dHaz[7* k + i] * S2(i+1, t2, k, Haz);
  }
  Free(newt);
  Free(newu);
  return(res);
}


SEXP VectorPDC(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		 SEXP timepoints) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PDC(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
		       *INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times));
      }
  /* R_CheckUserInterrupt(); */
  UNPROTECT(1);
  return(res);
}

double PDO(double u, double t, const int k, const int n,
	 const double *Haz,
	 const double *dHaz, const double *Times) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double res; res=0;
  int i,u2,t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  for (i= t2-1; i< u2; i++) {
    res = res + dHaz[8* k + i] * S2(i+1, t2, k, Haz);
  }
  Free(newt);
  Free(newu);
  return(res);
}

SEXP VectorPDO(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		 SEXP timepoints) {
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  int i;
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PDO(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
		 *INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times));
  /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}
double PD(double u, double t, int k, int n,
	 double *Haz,
	  double *dHaz, double *Times) {
  double res; res=0;
  res = 1 - (PDC(u, t, k, n, Haz, dHaz, Times) +
	      PDO(u, t, k, n, Haz, dHaz, Times));
  return(res);
}

double S1(int u, int t, int k, const double *Haz) {
  double res; res=0;
  res = exp(-((Haz[4* k+ u-1] + Haz[5* k+ u-1] + Haz[6* k+ u-1]) -
	      (Haz[4* k+ t-1] + Haz[5* k+ t-1]+ Haz[6* k+ t-1])));
  return(res);
}

double PLDC(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double x, double beta, double LR) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=7*k; j<8* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (LR + Times[i] - x));
	newdHaz[j] = newdHaz[j] * exp(beta * (LR + Times[i] - x));
      }
      res = res + dHaz[4* k +i] * S1(i+1, t2, k, Haz) *
	PDC(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPLDC(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP x, SEXP beta, SEXP LR) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PLDC(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(x), *REAL(beta), *REAL(LR));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}


double PLDO(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double x, double beta, double LR) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j, u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=7*k; j<8* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (LR + Times[i] - x));
	newdHaz[j] = newdHaz[j] * exp(beta * (LR + Times[i] - x));
      }
      for (i=t2-1; i<u2; i++) {
	res = res + dHaz[4* k +i] * S1(i+1, t2, k, Haz) *
	  PDO(Times[u2]-Times[i], 0, k, n, newHaz, newdHaz, Times);
      }
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

  SEXP VectorPLDO(SEXP t, SEXP k, SEXP n,
		SEXP Haz,
		SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP x, SEXP beta, SEXP LR) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PLDO(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(x), *REAL(beta), *REAL(LR));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PLC(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double res; res=0;
  int i,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      res = res + dHaz[5* k +i] * S1(i+1, t2, k, Haz);
    }
  }
  Free(newt);
  Free(newu);
  return(res);
}

SEXP VectorPLC(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PLC(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PLO(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double res; res=0;
  int i,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      res = res + dHaz[6* k +i] * S1(i+1, t2, k, Haz);
    }
  }
  Free(newt);
  Free(newu);
  return(res);
}

SEXP VectorPLO(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PLO(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PLD(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double x, double beta, double LR) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=7*k; j<8*k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (LR + Times[i] - x));
	newdHaz[j] = newdHaz[j] * exp(beta * (LR + Times[i] - x));
      }
      res = res + dHaz[4* k +i] * S1(i+1, t2, k, Haz) *
	PD(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPLD(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP x, SEXP beta, SEXP LR) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PLD(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(x), *REAL(beta), *REAL(LR));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PL(double u, double t, int k, int n,
	 double *Haz,
	  double *dHaz, double *Times, double x, double beta, double LR) {
  double res; res=0;
  res = 1 - (PLDC(u, t, k, n, Haz, dHaz, Times, x, beta, LR) +
	     PLDO(u, t, k, n, Haz, dHaz, Times, x, beta, LR) +
	     PLC(u, t, k, n, Haz, dHaz, Times) +
	     PLO(u, t, k, n, Haz, dHaz, Times) +
	     PLD(u, t, k, n, Haz, dHaz, Times, x, beta, LR)
	     );
  return(res);
}

double S0(int u, int t, int k, const double *Haz) {
  double res; res=0;
  res = exp(-((Haz[u-1] + Haz[1* k+ u-1] + Haz[2* k+ u-1] + Haz[3* k+ u-1]) -
	      (Haz[t-1] + Haz[1* k+ t-1] + Haz[2* k+ t-1] + Haz[3* k+ t-1])));
  return(res);
}

double PSLC(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double x, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=4*k; j<6* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - x));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - x));
      }
      res = res + dHaz[i] * S0(i+1, t2, k, Haz) *
	PLC(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}
SEXP VectorPSLC(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP x, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSLC(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(x), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PSLO(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double x, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=4*k; j<6* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - x));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - x));
      }
      res = res + dHaz[i] * S0(i+1, t2, k, Haz) *
	PLO(Times[u2]-Times[i], 0, k, n, newHaz, newdHaz, Times);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPSLO(SEXP t, SEXP k, SEXP n,
		SEXP Haz,
		SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP x, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSLO(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(x), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PSLD(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double xl, double xd, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=4*k; j<6* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - xl));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - xl));
      }
      res = res + dHaz[i] * S0(i+1, t2, k, Haz) *
	PLD(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times, xd, beta, Times[i]);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPSLD(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP xl, SEXP xd, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSLD(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(xl), *REAL(xd), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PSLDC(double u, double t,  int k,  int n,
	 double *Haz,
	     double *dHaz, double *Times, double xl, double xd, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=4*k; j<6* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - xl));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - xl));
      }
      res = res + dHaz[i] * S0(i+1, t2, k, Haz) *
	PLDC(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times, xd, beta, Times[i]);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPSLDC(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		 SEXP timepoints, SEXP xl, SEXP xd, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSLDC(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			 *REAL(xl), *REAL(xd), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PSLDO(double u, double t,  int k,  int n,
	 double *Haz,
	     double *dHaz, double *Times, double xl, double xd, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=4*k; j<6* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - xl));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - xl));
      }
      res = res + dHaz[i] * S0(i+1, t2, k, Haz) *
	PLDO(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times, xd, beta, Times[i]);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPSLDO(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		 SEXP timepoints, SEXP xl, SEXP xd, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSLDO(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			 *REAL(xl), *REAL(xd), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}


double PSL(double u, double t,  int k,  int n,
	 double *Haz,
	   double *dHaz, double *Times, double xl, double xd, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=4*k; j<6* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - xl));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - xl));
      }
      res = res + dHaz[i] * S0(i+1, t2, k, Haz) *
	PL(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times, xd, beta, Times[i]);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPSL(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
	       SEXP timepoints, SEXP xl, SEXP xd, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSL(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
		       *REAL(xl), *REAL(xd), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}


double PSDC(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double x, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=7*k; j<8* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - x));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - x));
      }
      res = res + dHaz[(1*k) + i] * S0(i+1, t2, k, Haz) *
	PDC(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPSDC(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP x, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSDC(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(x), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PSDO(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double x, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j, u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=7*k; j<8* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - x));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - x));
      }
      res = res + dHaz[(1*k) + i] * S0(i+1, t2, k, Haz) *
	PDO(Times[u2]-Times[i], 0, k, n, newHaz, newdHaz, Times);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPSDO(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP x, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSDO(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(x), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}


double PSD(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times, double x, double beta) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double *newHaz; newHaz=Calloc(k*9, double);
  double *newdHaz; newdHaz=Calloc(k*9, double);
  double res; res=0;
  int i,j,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< k * 9; i++) {
      newHaz[i] = Haz[i];
      newdHaz[i] = dHaz[i];
    }
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      for (j=0; j< k * 9; j++) {
	newHaz[j] = Haz[j];
	newdHaz[j] = dHaz[j];
      }
      for (j=7*k; j<8* k; j++) {
	newHaz[j] = newHaz[j] * exp(beta * (Times[i] - x));
	newdHaz[j] = newdHaz[j] * exp(beta * (Times[i] - x));
      }
      res = res + dHaz[(1*k) + i] * S0(i+1, t2, k, Haz) *
	PD(Times[u2-1]-Times[i], 0, k, n, newHaz, newdHaz, Times);
    }
  }
  Free(newt);
  Free(newu);
  Free(newHaz);
  Free(newdHaz);
  return(res);
}

SEXP VectorPSD(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints, SEXP x, SEXP beta) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSD(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times),
			*REAL(x), *REAL(beta));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}


double PSC(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double res; res=0;
  int i,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      res = res + dHaz[2* k +i] * S0(i+1, t2, k, Haz);
    }
  }
  Free(newt);
  Free(newu);
  return(res);
}

SEXP VectorPSC(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSC(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}


double PSO(double u, double t,  int k,  int n,
	 double *Haz,
	    double *dHaz, double *Times) {
  double *newt; newt=Calloc(n, double);
  double *newu; newu=Calloc(n, double);
  double res; res=0;
  int i,u2, t2;
  u2=0;
  t2=0;
  for (i=0; i< n; i++) {
    newt[i] = Times[i] - t;
  }
  int index = FirstNonNeg(newt, n);
  t2 = fmax(2, index);
  for (i=0; i< n; i++) {
    newu[i] = Times[i] - u;
  }
  u2 = FirstNonNeg(newu, n);
  if (t2<u2) {
    for (i=t2-1; i<u2; i++) {
      res = res + dHaz[3* k +i] * S0(i+1, t2, k, Haz);
    }
  }
  Free(newt);
  Free(newu);
  return(res);
}

SEXP VectorPSO(SEXP t, SEXP k, SEXP n,
	 SEXP Haz,
	 SEXP dHaz, SEXP Times,
		SEXP timepoints) {
  int i;
  int nt=length(timepoints);
  SEXP res = PROTECT(allocVector(REALSXP, nt));
  for (i=0; i< nt; i++) {
    REAL(res)[i] = PSO(REAL(timepoints)[i], *REAL(t), *INTEGER(k),
			*INTEGER(n), REAL(Haz), REAL(dHaz), REAL(Times));
    /* R_CheckUserInterrupt(); */
  }
  UNPROTECT(1);
  return(res);
}

double PS(double u, double t, int k, int n,
	 double *Haz,
	  double *dHaz, double *Times, double x, double xl, double xd, double beta) {
  double res; res=0;
  res = 1 - (PSLC(u, t, k, n, Haz, dHaz, Times, x, beta) +
	     PSLO(u, t, k, n, Haz, dHaz, Times, x, beta) +
	     PSLD(u, t, k, n, Haz, dHaz, Times, xl, xd , beta) +
	     PSLDC(u, t, k, n, Haz, dHaz, Times, xl, xd, beta) +
	     PSLDO(u, t, k, n, Haz, dHaz, Times, xl, xd, beta) +
	     PSL(u, t, k, n, Haz, dHaz, Times, xl, xd, beta) +
	     PSDC(u, t, k, n, Haz, dHaz, Times, x, beta) +
	     PSDO(u, t, k, n, Haz, dHaz, Times, x, beta) +
	     PSD(u, t, k, n, Haz, dHaz, Times, x, beta)  +
	     PSC(u, t, k, n, Haz, dHaz, Times)  +
	     PSO(u, t, k, n, Haz, dHaz, Times)
	     );
  return(res);
}
