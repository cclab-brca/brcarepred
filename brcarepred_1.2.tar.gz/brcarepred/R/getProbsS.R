getProbsS <-
    function(m, group=1, newdata, timepoints=NULL, start=0, beta=NULL,
             x=NULL,
             betaAGE=NULL, xAGE=NULL,
             compact=TRUE) {
    tra <- attr(newdata, "trans")
    probs <- list()
    StartHaz <- mstate::msfit(m, newdata=newdata, trans=tra)
    StartHaz <- StartHaz$Haz
    tmp <- split(StartHaz, StartHaz$trans)
    Times <- tmp[[1]]$time
    StartHaz <- do.call("cbind", lapply(tmp, function(x) x$Haz))
    group <- (group-1)*9 + 1
    StartHaz <- StartHaz[,group:(group+8)]
    StartdHaz <- apply(rbind(0, StartHaz), 2, diff)
    if (is.null(beta)) beta <- c(coef(m)['TLastSurgery'], coef(m)['TLastSurgery'])
    if (is.null(betaAGE)) betaAGE <- c(coef(m)['AGE.LR'], coef(m)['AGE.DR'])
    if (is.null(x)) x <- c(x=newdata[group+5, 'TLastSurgery'],
                           newdata[group+7, 'TLastSurgery'])
    if (is.null(xAGE)) xAGE <- c(x=newdata[group+6, 'AGE'] -
                                   newdata[group+3, 'AGE'],
                                 newdata[group+8, 'AGE'] -
                                 newdata[group+3, 'AGE'])
    if (is.null(timepoints)) {
        stop("timepoints required")
    } else {
        timepoints <- as.double(timepoints)
    }
    p.s.l.c <- .Call("VectorPSLC",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, x=x[1],
                     beta=beta[1], xAGE=xAGE[1],
                     betaAGE=betaAGE[1], PACKAGE="brcarepred")
    p.s.l.o <- .Call("VectorPSLO",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, x=x[1],
                     beta=beta[1], xAGE=xAGE[1],
                     betaAGE=betaAGE[1], PACKAGE="brcarepred")
    p.s.l.d <- .Call("VectorPSLD",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints,
                     xl=x[1], xd=x[2],
                     beta=beta[1], xlAGE=xAGE[1], xdAGE=xAGE[2],
                     betaAGE=betaAGE, PACKAGE="brcarepred")
    p.s.l.d.c <- .Call("VectorPSLDC",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, xl=x[1], xd=x[2],
                       beta=beta[1], xlAGE=xAGE[1], xdAGE=xAGE[2],
                     betaAGE=betaAGE, PACKAGE="brcarepred")
    p.s.l.d.o <- .Call("VectorPSLDO",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, xl=x[1], xd=x[2],
                       beta=beta[1], xlAGE=xAGE[1], xdAGE=xAGE[2],
                     betaAGE=betaAGE, PACKAGE="brcarepred")
    p.s.l <- .Call("VectorPSL",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, xl=x[1], xd=x[2],
                   beta=beta[1], xlAGE=xAGE[1], xdAGE=xAGE[2],
                     betaAGE=betaAGE[1], PACKAGE="brcarepred")
    p.s.d.c <- .Call("VectorPSDC",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, x=x[2],
                     beta=beta[2], xAGE=xAGE[2],
                   betaAGE=betaAGE[2], PACKAGE="brcarepred")
    p.s.d.o <- .Call("VectorPSDO",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, x=x[2],
                     beta=beta[2], xAGE=xAGE[2],
                     betaAGE=betaAGE[2], PACKAGE="brcarepred")
    p.s.d <- .Call("VectorPSD",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, x=x[2],
                   beta=beta[2], xAGE=xAGE[2],
                     betaAGE=betaAGE[2], PACKAGE="brcarepred")
    p.s.c <- .Call("VectorPSC",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                   timepoints=timepoints, PACKAGE="brcarepred")
    p.s.o <- .Call("VectorPSO",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                   timepoints=timepoints, PACKAGE="brcarepred")
    p.s <- 1 - (p.s.l.c + p.s.l.o + p.s.l.d + p.s.l.d.c + p.s.l.d.o  +
                    p.s.l + p.s.d.c + p.s.d.o + p.s.d + p.s.c + p.s.o)
    if (compact) {
        p.s.d <- p.s.d + p.s.l.d
        p.s.c <- p.s.c + p.s.l.c + p.s.l.d.c + p.s.d.c
        p.s.o <- p.s.o + p.s.l.o + p.s.l.d.o + p.s.d.o
        probs <- list(timepoints, p.s, p.s.l, p.s.d, p.s.c, p.s.o)
        names(probs) <- c("Times", "p.s", "p.s.l", "p.s.d", "p.s.c", "p.s.o")
        probs
    } else {
        probs <- list(timepoints, p.s, p.s.l.c ,  p.s.l.o ,  p.s.l.d ,  p.s.l.d.c ,  p.s.l.d.o  ,  p.s.l ,  p.s.d.c ,  p.s.d.o ,  p.s.d ,  p.s.c ,  p.s.o)
    names(probs) <- c("Times", "p.s", "p.s.l.c" ,  "p.s.l.o" ,  "p.s.l.d" ,  "p.s.l.d.c" ,  "p.s.l.d.o"  ,  "p.s.l" ,  "p.s.d.c" ,  "p.s.d.o" ,  "p.s.d" ,  "p.s.c" ,  "p.s.o")
        cat("PS done for ", timepoints, "\n")
        probs
    }
}
