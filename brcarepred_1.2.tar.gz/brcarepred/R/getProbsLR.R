getProbsLR <-
function(m, group=1, newdata, timepoints=NULL, start=0, beta=NULL, LR=NULL, DR=NULL, betaAGE=NULL, LRAGE=NULL, DRAGE=NULL, compact=TRUE) {
    if (is.null(timepoints)) {
        stop("timepoints required")
    } else {
        timepoints <- as.double(timepoints)
    }
    tra <- attr(newdata, "trans")
    probs <- list()
    StartHaz <- mstate::msfit(m, newdata=newdata, trans=tra)
    StartHaz <- StartHaz$Haz
    tmp <- split(StartHaz, StartHaz$trans)
    Times <- tmp[[1]]$time
    StartHaz <- do.call("cbind", lapply(tmp, function(x) x$Haz))
    group <- (group-1)*9 + 1
    StartHaz <- StartHaz[,group:(group+8)]
    StartdHaz <- apply(rbind(0, StartHaz), 2, diff)
    if (is.null(beta)) beta <- coef(m)['TLastSurgery']
    if (is.null(LR)) LR <- newdata[group+5, 'TLastSurgery']
    if (is.null(DR)) DR <- newdata[group+7, 'TLastSurgery']
    if (is.null(betaAGE)) betaAGE <- coef(m)['AGE.DR']
    if (is.null(LRAGE)) LRAGE <- 0
        if (is.null(DRAGE)) DRAGE <- newdata[group+8, 'AGE.DR'] -
            newdata[group + 6, 'AGE.LR']
    p.l.d.c <- .Call("VectorPLDC",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                     timepoints=timepoints, DR=DR,
                      beta=beta,
                     LR=LR, LRAGE=LRAGE,
                     DRAGE=DRAGE, betaAGE=betaAGE, PACKAGE="brcarepred")
    p.l.d.o <- .Call("VectorPLDO",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                     dHaz=StartdHaz, Times=Times, timepoints=timepoints,
                     DR=DR,
                     beta=beta,
                     LR=LR, LRAGE=LRAGE,
                     DRAGE=DRAGE, betaAGE=betaAGE,
                     PACKAGE="brcarepred")
    p.l.c <- .Call("VectorPLC",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                   dHaz=StartdHaz, Times=Times,
                   timepoints=timepoints, PACKAGE="brcarepred")
    p.l.o <- .Call("VectorPLO",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                   dHaz=StartdHaz, Times=Times,
                   timepoints=timepoints, PACKAGE="brcarepred")
    p.l.d <- .Call("VectorPLD",
                t=start, k=nrow(StartHaz),
                n=length(Times), Haz=StartHaz,
                dHaz=StartdHaz, Times=Times,
                   timepoints=timepoints, DR=DR,
                   beta=beta,
                   LR=LR, LRAGE=LRAGE,
                   DRAGE=DRAGE, betaAGE=betaAGE,
                   PACKAGE="brcarepred")
    p.l <- 1 - (p.l.d.c + p.l.d.o + p.l.c + p.l.o + p.l.d)
    if (compact) {
        probs <- list(timepoints, p.l, p.l.d, p.l.c+p.l.d.c, p.l.o+p.l.d.o)
        names(probs) <- c("Times", "p.l", "p.l.d", "p.l.c", "p.l.o")
        probs
    } else {
        probs <- list(timepoints, p.l, p.l.d, p.l.c,p.l.d.c, p.l.o,p.l.d.o)
        names(probs) <- c("Times", "p.l", "p.l.d", "p.l.c", "p.l.d.c",
                          "p.l.o", "p.l.d.o")
        probs
    }
}
